class PerfectMappingError(Exception):
    """Exception for features with a perfect 1-to-1 mapping with the target."""
    pass